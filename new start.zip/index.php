<?php include 'include/header.php' ?>
<div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel" data-interval="3000">
    <div class="carousel-inner">
        <div class="carousel-item position-relative active">
            <img src="images/sliders/slider-img-1.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">

                    <p class="carousel-title mt-3">Excavating Excellence<br>Every Time</p>
                    <p class="carousel-para h6">Your Trusted Partner for Precision Earthworks, Excavation, and Material
                        Supply.
                    </p>

                </div>
            </div>
        </div>
        <div class="carousel-item position-relative ">
            <img src="images/sliders/slider-img-2.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">

                    <p class="carousel-title mt-3">Shaping Landscapes<br>Building Dreams</p>
                    <p class="carousel-para h6">Bringing Your Projects to Life, Safely and Sustainably. </p>

                </div>
            </div>
        </div>
        <div class="carousel-item position-relative">
            <img src="images/sliders/slider-img-3.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">
                    <p class="carousel-title mt-3">Quality, Precision,<br>and Commitment</p>
                    <p class="carousel-para h6">We provide Good quality service, at affordable price.</p>
                </div>
            </div>
        </div>
        <div class="carousel-item position-relative">
            <img src="images/sliders/slider-img-5.png" class="d-block w-100 image-filter object-cover" alt="">

            <div class="carousel-caption">
                <div class="text-left">

                    <p class="carousel-title mt-3">27 years of <br>Experience</p>
                    <p class="carousel-para h6">we are the The Earthwork Experts you need.</p>

                </div>
            </div>
        </div>

    </div>
</div>


<section>
    <div class="d-flex justify-content-between align-items-center">
        <div class="position-relative">
            <div class="about_img">
                
            </div>
        </div>

        <div class="p-3">
                <h1>About Us</h1>
            </div>

    </div>
</section>



<?php include 'include/footer.php' ?>